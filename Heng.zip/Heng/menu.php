<html>
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="css/menu.css">
	<link rel="stylesheet" type="text/css" href="stylesheet.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">

	<title>Delivery | Menu</title>
</head>

<body>

	<div id="head">
		<div id="logo">
			<img src="img/logo.png">
		</div><!-- END LOGO -->

		<div class="menu">

            <center><ul>
                <li><a href="#">&nbsp HOME &nbsp</a></li>
                <li><a href="menu.php"class="active">&nbsp DELIVERY &nbsp</a></li>
                <li><a href="#">&nbsp BOOKING &nbsp</a></li>
                <li><a href="#">&nbsp PROMOTION &nbsp</a></li>
                <li><a href="#">&nbsp CONTACT &nbsp</a></li>

            </ul></center>
        </div>

        <div class="menu-right">
        	<ul>
        		<li> <i class="fa fa-shopping-cart"></i></li> |
        		<li>&nbsp PAKAKOL</li>
        	</ul>

        </div><!-- end menu-right -->



	</div> <!-- END HEAD -->

	<div class="head-dot"></div> &nbsp;

	<div class="menu-2">
		<h1>MENU  &nbsp&nbsp&nbsp&nbsp&nbsp 
			<a href="#" class="active-border">&nbsp&nbsp อาหาร &nbsp&nbsp</a> &nbsp&nbsp&nbsp&nbsp
			<a href="#">&nbsp&nbsp เครื่องดื่ม &nbsp&nbsp</a></h1>
	</div><!-- end menu2 -->

	<div class="timeline">
		<img src="img/time1.png">
	</div><!-- end timeline -->



<!--Food Line 1 -->
	<div class="wrap-food">

		<div class="box1">
			<div class="img-food"><img src="img/f1.png"></div>
			<div class="detail-food">เส้นใหญ่ราดหน้า <br>
				<p2>ราคา 40 บาท</p2>
			</div><!-- detail-food -->

			<div class="button-cart">
				<button class="cart"><i class="fa fa-shopping-cart"></i>&nbsp;เพิ่มลงตระกร้า</button>
			</div><!-- end button-cart -->
		</div><!-- box1 -->


		<div class="box1">
			<div class="img-food"><img src="img/f2.png"></div>
			<div class="detail-food">เส้นใหญ่ราดหน้า <br>
				<p2>ราคา 40 บาท</p2>
			</div><!-- detail-food -->

			<div class="button-cart">
				<button class="cart"><i class="fa fa-shopping-cart"></i>&nbsp;เพิ่มลงตระกร้า</button>
			</div><!-- end button-cart -->
		</div><!-- box1 -->


		<div class="box1">
			<div class="img-food"><img src="img/f3.png"></div>
			<div class="detail-food">เส้นใหญ่ราดหน้า <br>
				<p2>ราคา 40 บาท</p2>
			</div><!-- detail-food -->

			<div class="button-cart">
				<button class="cart"><i class="fa fa-shopping-cart"></i>&nbsp;เพิ่มลงตระกร้า</button>
			</div><!-- end button-cart -->
		</div><!-- box1 -->


	</div><!-- end wrap-food -->





	<!--Food Line 2 -->
	<div class="wrap-food"></center>

		<div class="box1">
			<div class="img-food"><img src="img/f4.png"></div>
			<div class="detail-food">เส้นใหญ่ราดหน้า <br>
				<p2>ราคา 40 บาท</p2>
			</div><!-- detail-food -->

			<div class="button-cart">
				<button class="cart"><i class="fa fa-shopping-cart"></i>&nbsp;เพิ่มลงตระกร้า</button>
			</div><!-- end button-cart -->
		</div><!-- box1 -->


		<div class="box1">
			<div class="img-food"><img src="img/f5.png"></div>
			<div class="detail-food">เส้นใหญ่ราดหน้า <br>
				<p2>ราคา 40 บาท</p2>
			</div><!-- detail-food -->

			<div class="button-cart">
				<button class="cart"><i class="fa fa-shopping-cart"></i>&nbsp;เพิ่มลงตระกร้า</button>
			</div><!-- end button-cart -->
		</div><!-- box1 -->


		<div class="box1">
			<div class="img-food"><img src="img/f6.png"></div>
			<div class="detail-food">เส้นใหญ่ราดหน้า <br>
				<p2>ราคา 40 บาท</p2>
			</div><!-- detail-food -->

			<div class="button-cart">
				<button class="cart"><i class="fa fa-shopping-cart"></i>&nbsp;เพิ่มลงตระกร้า</button>
			</div><!-- end button-cart -->
		</div><!-- box1 -->


	</div><!-- end wrap-food -->




	<!--Food Line 3 -->
	<div class="wrap-food"></center>

		<div class="box1">
			<div class="img-food"><img src="img/f7.png"></div>
			<div class="detail-food">เส้นใหญ่ราดหน้า <br>
				<p2>ราคา 40 บาท</p2>
			</div><!-- detail-food -->

			<div class="button-cart">
				<button class="cart"><i class="fa fa-shopping-cart"></i>&nbsp;เพิ่มลงตระกร้า</button>
			</div><!-- end button-cart -->
		</div><!-- box1 -->


		<div class="box1">
			<div class="img-food"><img src="img/f8.png"></div>
			<div class="detail-food">เส้นใหญ่ราดหน้า <br>
				<p2>ราคา 40 บาท</p2>
			</div><!-- detail-food -->

			<div class="button-cart">
				<button class="cart"><i class="fa fa-shopping-cart"></i>&nbsp;เพิ่มลงตระกร้า</button>
			</div><!-- end button-cart -->
		</div><!-- box1 -->


		<div class="box1">
			<div class="img-food"><img src="img/f9.png"></div>
			<div class="detail-food">เส้นใหญ่ราดหน้า <br>
				<p2>ราคา 40 บาท</p2>
			</div><!-- detail-food -->

			<div class="button-cart">
				<button class="cart"><i class="fa fa-shopping-cart"></i>&nbsp;เพิ่มลงตระกร้า</button>
			</div><!-- end button-cart -->
		</div><!-- box1 -->


	</div><!-- end wrap-food --> 


	<div class="next-button"><a href="cart.php"><button class="next">Next</button></a></div>
	
	<div class="head-dot"></div> <br>

	<footer><center><img src="img/footer.png"></center></footer>




</body>
</html>