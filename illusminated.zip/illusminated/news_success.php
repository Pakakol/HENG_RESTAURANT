<html>
<head>
	<title>Success</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/success_style.css">
	<link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>

	<center> 

		<h1>Upload News Success</h1>

		<div id="wrapping-menu"> 

  <div id="wrapmenu-2">
    
    <a href="news_upload.php"><div class="menubox">

    	

        <img class="menubox-img" src="images/uploads-icon.png"> 

    </div><!-- mebubox --></a>

    <a href="adminpage.php"><div class="menubox">

    	

        <img class="menubox-img" src="images/home-icon.png"> 

    </div><!-- mebubox --></a>

	</center>

</body>
</html>