<html>
<head>
	<title>Success</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/success_style.css">
	<link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>

	<center> 

		<h1>Contact Works Success</h1>

		<div id="wrapping-menu"> 

  <div id="wrapmenu-2">
    
    <a href="home.php"><div class="menubox">

    	

        <img class="menubox-img" src="images/home-icon.png"> 

    </div><!-- mebubox --></a>

	</div>



	</center>

</body>
</html>