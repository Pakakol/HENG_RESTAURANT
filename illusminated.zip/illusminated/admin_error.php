<html>
<head>
	<title>Sorry</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/success_style.css">
	<link rel="stylesheet" type="text/css" href="stylesheet.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
</head>
<body>
	<center>

	<div class="box-warn">

	<h1> Sorry! This Page is For Admin Only <br> 
		<h2> 
		Thank you</h2>

	</h1>

	

	<div id="wrapping-menu"> 

  <div id="wrapmenu-2">
    
    <a href="home.php"><div class="menubox">

    	

        <img class="menubox-img" src="images/home-icon.png"> 

    </div><!-- mebubox --></a>

	

</center>

</body>
</html>