<html>
<head>
	<title>Successful</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="css/success_style.css">
	<link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>

	<center>
		<br>
		<h1>Successful!</h1>

		<div id="wrapping-menu"> 

  <div id="wrapmenu-2">
    
    <a href="uploads.php"><div class="menubox">

    	

        <img class="menubox-img" src="images/uploads-icon.png"> 

    </div><!-- mebubox --></a>

    <a href="home.php"><div class="menubox">

    	

        <img class="menubox-img" src="images/home-icon.png"> 

    </div><!-- mebubox --></a>


	</center> 

</body>
</html>