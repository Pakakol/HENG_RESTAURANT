<html>
<head>
	<title>Sorry</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/success_style.css">
	<link rel="stylesheet" type="text/css" href="stylesheet.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
</head>
<body>
	<center>

	<div class="box-warn">

	<h1> Sorry! This Page is For Designer </h1> <br> 
		<h2>if you want to use this Please Login or Signup <br><br>
		Thank you</h2>

	

	<div id="wrapping-menu"> 

  <div id="wrapmenu-2">
    
    <a href="home.php"><div class="menubox">

    	

        <img class="menubox-img" src="images/home-icon.png"> 

    </div><!-- mebubox --></a>

	</div>

</center>

</body>
</html>