<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>iLLUSMINATED.com</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link rel="stylesheet" href="css/normalize.css">

    
        <link rel="stylesheet" href="css/style.css">

    
    
    
  </head>

  <body>

    <a href="home.php" class="hero-btn">
  WELCOME  TO<br><span class="str">iLLUSMINATED</span>
  <br>.COM<br>
</a>
<div class="bg"></div>
    
        <script src="js/index.js"></script>

    
    
    
  </body>
</html>
